package com.example.myapplication2

import android.os.Bundle
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import android.content.Intent
import android.content.Context
import android.widget.Button
import androidx.core.app.ActivityOptionsCompat

class MainActivity : AppCompatActivity() {


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        val button = findViewById<Button>(R.id.btnLogin)

        btnLogin.setOnClickListerer {

            var intentMarket = Intent(this, MapsActivity::class.java)
            val p1 = androidx.core.util.Pair.create<View,String>(ivLogo,b:"logo")
            val options = ActivityOptionsCompat.makeSceneTransitionAnimation(this, p1)

            startActivity(intentMarket, options.toBundle())
        }
    }
}
