package com.example.myapplication2

import android.content.ActivityNotFoundException
import android.content.IntentSender
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

import com.google.android.gms.maps.CameraUpdateFactory
import com.google.android.gms.maps.GoogleMap
import com.google.android.gms.maps.OnMapReadyCallback
import com.google.android.gms.maps.SupportMapFragment
import com.google.android.gms.maps.model.LatLng
import com.google.android.gms.maps.model.MarkerOptions
import com.example.myapplication2.databinding.ActivityMaps2Binding

class MapsActivity : AppCompatActivity(), OnMapReadyCallback {

    private lateinit var mMap: GoogleMap
    private lateinit var binding: ActivityMaps2Binding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        binding = ActivityMaps2Binding.inflate(layoutInflater)
        setContentView(binding.root)

        // Obtain the SupportMapFragment and get notified when the map is ready to be used.
        val mapFragment = supportFragmentManager
            .findFragmentById(R.id.map) as SupportMapFragment
        mapFragment.getMapAsync(this)

        btnNavigate.setOnClickLister{
            startNavigation()
        }

        btnPublish.setOnClickLister{
            publishEvent()
        }

        private fun startNavigation(){
            val lat = newMarker?.position?.latitude
            val lng = newMarker?.position?.longtitude

            val WazeUri ="waze://?q=Kaposvár&navigate=yes"

            val intentTest = Intent(Intent.ACTION_VIEW)
            IntentTest.data = Uri.parse(wazeUri)
            startActivity(intentTest)
        }

        private fun publishEvent(){
            val intentSend = Intent(Intent.ACTION_SEND)
            intentSend.type = "text/plain"
            intentSend.putExtra(Intent.EXTRA_TEXT, "https://facebook.com/bolhapiacom")

            intentSend.setPackage("com.facebook.katana")

            try{
                startActivity(intentSend)
            } catch (e: ActivityNotFoundException){
                e.printStackTrace()
            }
        }
    }

    var newMarker = Marker? = null

    override fun onMapReady(googleMap: GoogleMap) {
        mMap = googleMap

        mMap.uiSettings.isZoomGesturesEnabled
        mMap.uiSettings.isZoomControlsEnabled

        mMap.setOnMapClickListener {
            if (newMarker == null){
                mMap.clear()
                newMarker = mMap.addMarker(
                    MarkerOptions()
                        .position(it)
                        .title("My Marker")
                        .snippet("long text of marker")
                )
                newMarker.isDraggable = true
            } else {
                newMarker?.position = it
            }
            updateAddress()
            mMap.animateCamera(CameraUpdateFactory.newLatLng(it))
        }

        // Add a marker in Sydney and move the camera
        val sydney = LatLng(-34.0, 151.0)
        mMap.addMarker(MarkerOptions().position(sydney).title("Marker in Sydney"))
        mMap.moveCamera(CameraUpdateFactory.newLatLng(sydney))
    }
}